These files must contain at least in the compiler pack:

* package.json
* MyCompilerName.js
* path-to-icon/compilerName.png

[How to create a compiler extension?](https://github.com/oklai/koala/wiki/How-to-create-a-compiler-extension%3F)